import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'my-app';
  Categorylist; SupplierList;
  baseurl = "http://localhost:50335/api";
  Product: any = {
    ID: 0,
    ProductName: "",
    CategoryID: 0,
    UnitPRice: 0,
    ReorderLevel: 0,
    Discontinued: true,
    Supplier: ""
  };
  prdList;

  constructor(private httpClient: HttpClient,    private router: Router,
    ) {
    this.get_products();
    this.get_supplier();
    this.get_savedProducts();
  }
  update(){
    this.Product.Supplier=this.Product.Supplier.toString();
     console.log(this.Product);
     if(this.Product.Discontinued==true)
     this.Product.Discontinued=1;
     else
     this.Product.Discontinued=0;
 
     this.httpClient.post(this.baseurl + '/Home/UpdateProduct',this.Product).subscribe(
       data => {
         
         console.log("POST Request is successful ", data);
         this.callclear();
         alert("Product Updated Successfully"); 
         this.get_savedProducts();
         this.onRefresh("");

       },
       error => {
         console.log("Error", error);
       }
 
     );
  }

  submit() {

   this.Product.Supplier=this.Product.Supplier.toString();
    console.log(this.Product);
    if(this.Product.Discontinued==true)
    this.Product.Discontinued=1;
    else
    this.Product.Discontinued=0;

    this.httpClient.post(this.baseurl + '/Home/SaveProduct',this.Product).subscribe(
      data => {
        console.log("POST Request is successful ", data);
        this.callclear();this.get_savedProducts();
alert("Product saved Successfully");        this.onRefresh("");

        
      },
      error => {
        console.log("Error", error);
      }

    );
  }
  onRefresh(url){
    this.router.navigateByUrl("/").then(() => {
      this.router.navigated = false;
      this.router.navigate([url]);
    });
  }
  LoadModel(pr){
    console.log(pr);
    this.Product.ID = pr.ID;
    this.Product.ProductName = pr.ProductName;
    this.Product.CategoryID = pr.CategoryID;
    this.Product.UnitPRice = pr.UnitPRice;
    this.Product.ReorderLevel = pr.ReorderLevel;
    this.Product.Discontinued = pr.Discontinued;
    this.Product.Supplier = JSON.parse("[" + pr.Supplier + "]");

  }


  callclear() {
    this.Product.ID = 0;
    this.Product.ProductName = "";
    this.Product.CategoryID = 0;
    this.Product.UnitPRice = 0;
    this.Product.ReorderLevel = 0;
    this.Product.Discontinued = 0
    this.Product.Supplier = "";

  }
  get_savedProducts() {

    this.httpClient.get(this.baseurl + '/Home/GetProductsList').subscribe((res: any[]) => {
      this.prdList = res;

    })
  }
  get_products() {
    this.httpClient.get(this.baseurl + '/Home/GetCategoryList').subscribe((res: any[]) => {
      this.Categorylist = res;
    });
  }
  get_supplier() {
    this.httpClient.get(this.baseurl + '/Home/GetSupplierList').subscribe((res: any[]) => {
      this.SupplierList = res;
    });
  }

}
